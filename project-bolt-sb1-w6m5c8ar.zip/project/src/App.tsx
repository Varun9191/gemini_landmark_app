import React, { useState } from 'react';
import { Building2, Camera, Upload, History } from 'lucide-react';
import { LandmarkCard } from './components/LandmarkCard';
import { cn } from './lib/utils';

function App() {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
        setIsAnalyzing(true);
        // Simulate analysis delay
        setTimeout(() => setIsAnalyzing(false), 2000);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Building2 className="w-8 h-8 text-indigo-600" />
              <h1 className="text-xl font-bold text-gray-900">Landmark Explorer</h1>
            </div>
            <nav className="flex items-center space-x-4">
              <button className="flex items-center space-x-1 text-gray-600 hover:text-gray-900">
                <History className="w-5 h-5" />
                <span>History</span>
              </button>
            </nav>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Discover the Stories Behind Landmarks
            </h2>
            <p className="text-lg text-gray-600">
              Upload a photo of any landmark to learn about its history and significance
            </p>
          </div>

          <div className="mb-12">
            <label 
              className={cn(
                "relative block w-full aspect-video rounded-lg border-2 border-dashed border-gray-300 hover:border-indigo-400 transition-colors cursor-pointer",
                "bg-gray-50 hover:bg-gray-100"
              )}
            >
              <input
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleImageUpload}
              />
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <Upload className="w-12 h-12 text-gray-400 mb-4" />
                <p className="text-sm text-gray-600">
                  Drop your image here or click to upload
                </p>
              </div>
              {selectedImage && (
                <img
                  src={selectedImage}
                  alt="Selected landmark"
                  className="absolute inset-0 w-full h-full object-cover rounded-lg"
                />
              )}
            </label>
          </div>

          {isAnalyzing ? (
            <div className="text-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mx-auto mb-4"></div>
              <p className="text-gray-600">Analyzing your landmark...</p>
            </div>
          ) : selectedImage && (
            <LandmarkCard
              name="Eiffel Tower"
              description="The Eiffel Tower is a wrought-iron lattice tower located on the Champ de Mars in Paris, France. It is named after the engineer Gustave Eiffel, whose company designed and built the tower. Constructed from 1887 to 1889 as the entrance to the 1889 World's Fair, it was initially criticized by some of France's leading artists and intellectuals for its design, but it has become a global cultural icon of France."
              location="Paris, France"
              yearBuilt="1889"
              imageUrl="https://images.unsplash.com/photo-1543349689-9a4d426bee8e?auto=format&fit=crop&q=80"
              className="mb-8"
            />
          )}
        </div>
      </main>
    </div>
  );
}

export default App;