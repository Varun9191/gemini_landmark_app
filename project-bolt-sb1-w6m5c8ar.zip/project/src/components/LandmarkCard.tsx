import React from 'react';
import { Building2, Clock, MapPin } from 'lucide-react';
import { cn } from '../lib/utils';

interface LandmarkCardProps {
  name: string;
  description: string;
  location: string;
  yearBuilt: string;
  imageUrl: string;
  className?: string;
}

export function LandmarkCard({
  name,
  description,
  location,
  yearBuilt,
  imageUrl,
  className,
}: LandmarkCardProps) {
  return (
    <div className={cn("bg-white rounded-xl shadow-lg overflow-hidden", className)}>
      <div className="relative h-64">
        <img
          src={imageUrl}
          alt={name}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
        <h3 className="absolute bottom-4 left-4 text-2xl font-bold text-white">{name}</h3>
      </div>
      
      <div className="p-6">
        <div className="flex items-center gap-4 mb-4 text-sm text-gray-600">
          <div className="flex items-center gap-1">
            <MapPin className="w-4 h-4" />
            <span>{location}</span>
          </div>
          <div className="flex items-center gap-1">
            <Clock className="w-4 h-4" />
            <span>{yearBuilt}</span>
          </div>
        </div>
        
        <p className="text-gray-700 leading-relaxed">{description}</p>
      </div>
    </div>
  );
}